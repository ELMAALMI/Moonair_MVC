create definer = root@localhost trigger setEmp
    before delete
    on departments
    for each row
BEGIN

DECLARE done INT DEFAULT 0;
DECLARE emp INT(11);
DECLARE emp_dept INT(11);
DECLARE list_emp CURSOR FOR
SELECT employee_id, department_id FROM employees WHERE department_id = OLD.department_id;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

OPEN list_emp;

REPEAT
FETCH list_emp INTO emp, emp_dept;

    UPDATE employees SET department_id = 111
    WHERE employee_id = emp;

UNTIL done
END REPEAT;

CLOSE list_emp;

END;

