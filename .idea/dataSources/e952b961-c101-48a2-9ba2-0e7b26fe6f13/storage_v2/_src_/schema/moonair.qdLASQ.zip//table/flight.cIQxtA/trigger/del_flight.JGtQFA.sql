create definer = root@localhost trigger del_flight
    before delete
    on flight
    for each row
    DELETE FROM flights_history
WHERE flight_num = OLD.flight_num;

