create definer = root@localhost trigger add_flight_historic
    before insert
    on flight
    for each row
    INSERT INTO flights_history VALUES(NEW.flight_num,NEW.plane_id,NEW.line_num,NEW.depart_date,NEW.arrival_date,NEW.Available_places);

