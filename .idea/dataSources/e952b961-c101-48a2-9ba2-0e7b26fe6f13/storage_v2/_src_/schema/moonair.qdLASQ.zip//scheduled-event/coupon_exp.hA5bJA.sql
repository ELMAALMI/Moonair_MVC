create definer = root@localhost event coupon_exp on schedule
    every '5' SECOND
        starts '2020-02-24 13:45:47'
    enable
    do
    UPDATE moonair.coupons SET coupons.status = 'Expirated'
        WHERE coupons.expiration_date <= CURRENT_DATE AND coupons.status NOT LIKE 'USED';

