create definer = root@localhost trigger av_plc
    before insert
    on ticket
    for each row
BEGIN

DECLARE v_resv integer;
DECLARE v_flight integer;
DECLARE av_plc integer;

SELECT resv_num INTO v_resv FROM ticket WHERE ticket_num = NEW.ticket_num;
SELECT flight_num INTO v_flight FROM reservation WHERE resv_num = v_resv;
SELECT Available_places INTO av_plc FROM flight WHERE flight_num = v_flight;

UPDATE flight
SET Available_places = (av_plc - 1)
WHERE flight_num = v_flight;

END;

