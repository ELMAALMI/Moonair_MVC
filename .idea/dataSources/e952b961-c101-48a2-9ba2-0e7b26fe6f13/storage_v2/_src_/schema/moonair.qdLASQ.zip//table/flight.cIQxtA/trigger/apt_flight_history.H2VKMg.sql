create definer = root@localhost trigger apt_flight_history
    before update
    on flight
    for each row
    UPDATE flights_history 
SET flight_num = NEW.flight_num, plane_id = NEW.plane_id,line_num = NEW.line_num,depart_date = NEW.depart_date, arrival_date = NEW.arrival_date, Available_places = NEW.Available_places
WHERE flight_num = NEW.flight_num;

